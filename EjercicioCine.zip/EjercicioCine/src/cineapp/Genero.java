package cineapp;

public enum  Genero {
	 Drama, Comedia, Aventuras, Terror, Musical, Infantil
}
